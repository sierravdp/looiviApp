from django.contrib import admin

from .models import Business

admin.site.register(Business)