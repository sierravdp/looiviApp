---
layout: doc
weight: 1
title: Release history
categories: developers
permalink: /developers/changelog/
---

On <a href="https://github.com/usablica/intro.js/blob/master/changelog.md">Release History</a> page you can find a complete list of releases history.
